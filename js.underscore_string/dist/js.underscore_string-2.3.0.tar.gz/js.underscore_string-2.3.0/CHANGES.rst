CHANGES
*******

2.3.0
=====

- Initial release. (version number is underscore.string.js's one)
